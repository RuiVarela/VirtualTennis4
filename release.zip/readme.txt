Virtual Tennis 4

Para jogar tem de validar todos os jogadores que pretendem jogar.

Exempo:

Equipa: Hardcoder......Vs......Equipa: Pixies
Ryven(humano)......................Houdini(humano)
...................................................Nuno(humano)

Para a Equipa da Esquerda:

-> Clique na ComboBox "Equipa" e escolha "Esquerda".
-> Digite em "Nome Da Equipa" Hardcoders.
-> Cique na ComboBox "Jogador" e escolha "Humano".
-> Clique na ComboBox "Modo" e escolha "Singular".
-> Digite em "Nome" Ryven.

5� Clique "Validar Jogador" (Vai usar as teclas por omiss�o cima,baixo,esquerda,direita)

Para a Equipa da Direita:

-> Clique na ComboBox "Equipa" e escolha "Direita".
-> Digite em "Nome Da Equipa" Pixies.
-> Clique na ComboBox "Modo" e escolha "Pares".
-> Clique na ComboBox "Numero" e escolha "1".
-> Digite em "Nome" Houdini.
-> Clique em "Definir Teclas". (digite as teclas...)
-> Clique "Validar Jogador".
-> Clique na ComboBox "Numero" e escolha "2"
-> Digite em "Nome" Nuno.
-> Clique em "Definir Teclas". (digite as teclas...)
-> Clique "Validar Jogador".

Clique "Start" para kome�ar.

Virtual Tennis 4 por
Ryven
Houdini
Nuno